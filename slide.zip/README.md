
  # Create Interactive Report Slide

  This is a code bundle for Create Interactive Report Slide. The original project is available at https://www.figma.com/design/KAkCnySOUT1Y8ywJv715Lt/Create-Interactive-Report-Slide.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  